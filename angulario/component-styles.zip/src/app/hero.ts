export class Hero {
  active: boolean;

  constructor(public name: string,
              public team: string[]) {
  }
}
